/**
 * Package for calculate task.
 *
 * @author Aleksandr Kochkurkin (mailto:info@debitop.com)
 * @version $Id$
 * @since 09.09.2018
 */
package ru.job4j.calculate;